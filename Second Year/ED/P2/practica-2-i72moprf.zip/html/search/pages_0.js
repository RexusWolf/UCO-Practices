var searchData=
[
  ['implementación_20de_20un_20polinomio',['Implementación de un Polinomio',['../index.html',1,'']]]
];
