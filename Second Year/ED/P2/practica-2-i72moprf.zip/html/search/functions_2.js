var searchData=
[
  ['getgrado',['getGrado',['../classed_1_1Polinomio.html#ab2459419194108f5787eb4bfa768c689',1,'ed::Polinomio::getGrado()'],['../classed_1_1PolinomioInterfaz.html#a7d6b7000f661d225b54486165ad4e6fc',1,'ed::PolinomioInterfaz::getGrado()']]],
  ['getmonomio',['getMonomio',['../classed_1_1Polinomio.html#ae46f294020381f20d91227cbded6f3bf',1,'ed::Polinomio::getMonomio()'],['../classed_1_1PolinomioInterfaz.html#aac31e2599c275a8b8013c00cd3aa171a',1,'ed::PolinomioInterfaz::getMonomio()']]],
  ['getnumeromonomios',['getNumeroMonomios',['../classed_1_1Polinomio.html#a6dfec736c99f0ae621aad6d23abc4854',1,'ed::Polinomio::getNumeroMonomios()'],['../classed_1_1PolinomioInterfaz.html#aaad12c08b5cb0bfa402f553d2ca622ec',1,'ed::PolinomioInterfaz::getNumeroMonomios()']]]
];
