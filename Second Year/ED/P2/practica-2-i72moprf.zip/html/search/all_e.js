var searchData=
[
  ['yellow',['YELLOW',['../macros_8hpp.html#abf681265909adf3d3e8116c93c0ba179',1,'macros.hpp']]]
];
